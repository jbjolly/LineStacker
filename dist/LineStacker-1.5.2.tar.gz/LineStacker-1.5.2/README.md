Python module to stack spectra in the image domain.

Requirements:
casapy
+ everything required to run casa

Documentation can be accessed here:
https://jbjolly.github.io/LineStacker/

Or by running docs/index.html or docs/LineStacker.pdf
